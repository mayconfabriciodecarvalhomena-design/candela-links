// -----------------------------------------------------------------------
// FINALE_CONFIG: fuente de verdad de la configuración de la primera
// parte del final de Candela (src/candelaFinale.js + src/envelopeMesh.js).
// Mismo patrón que el resto de sistemas (flame.config.js,
// flameWords.config.js...): este archivo es responsabilidad exclusiva de
// este sistema; config.js solo lo importa y lo expone como
// CONFIG.finale, sin duplicar valores.
//
// ALCANCE DE ESTA FASE (ver el encargo): desde que termina la última
// frase de FlameWords hasta que el sobre, ya formado y viajado hasta el
// centro de la cámara, queda completamente abierto. NO incluye hojas,
// texto editable, ni nada de backend — eso es responsabilidad de una
// fase posterior.
//
// SECUENCIA COMPLETA (ver candelaFinale.js para la máquina de estados
// real):
//
//   pause → flameSurge → (particles) birth → rise → converge →
//   materialize → travel → settle → open → done
//
// -----------------------------------------------------------------------
export const FINALE_CONFIG = {
  // -----------------------------------------------------------------------
  // 1) PAUSA tras la última frase de FlameWords (ver sección 1 del
  // encargo). Debe notarse claramente más larga que la separación
  // normal entre frases de la secuencia automática
  // (CONFIG.flameWords.autoSequence.gapBetweenPhrases, 4.0s) — aquí
  // 5.5s. No es la misma pausa: FlameWords ya inserta su propio
  // "gapBetweenPhrases" antes de darse cuenta de que la lista se ha
  // acabado (ver flameWords.js → updateAutoSequence), así que esta
  // pausa se SUMA a esa, no la sustituye. Sin efectos nuevos, sin mover
  // la cámara, sin cambiar la iluminación — la habitación simplemente
  // sigue viva.
  // -----------------------------------------------------------------------
  pause: {
    duration: 5.5,
  },

  // -----------------------------------------------------------------------
  // 2) CRECIMIENTO DE LA LLAMA (ver sección 2 del encargo). Gobierna
  // flame.setSurge() (añadido aditivo en flame.js — ver el bloque de
  // comentarios "SURGE" ahí) llamado desde candelaFinale.js. La
  // MAGNITUD de la respuesta visual (cuánto crece/brilla/parpadea la
  // llama) vive en CONFIG.flame.surge (flame.config.js, responsabilidad
  // de ese sistema); aquí solo se define el RITMO con el que se recorre
  // ese rango 0→1→0:
  //
  //   riseDuration → sube de 0 a `peak` (acumulación de energía).
  //   holdDuration → se mantiene en `peak` (el pico, "preparar
  //     visualmente el nacimiento del sobre").
  //   fallDuration → vuelve a bajar a 0 — SOLAPADO con el nacimiento y
  //     ascenso de las partículas (ver particles.startDelay más abajo),
  //     no es una fase bloqueante propia: la llama se va calmando
  //     MIENTRAS las partículas ya están naciendo, para que quede en un
  //     estado coherente ("puede volver a su estado normal") sin cortar
  //     en seco el crecimiento anterior.
  // -----------------------------------------------------------------------
  flameSurge: {
    riseDuration: 2.2,
    holdDuration: 1.0,
    fallDuration: 3.2,
    peak: 1.0,

    // -----------------------------------------------------------------------
    // DEFORM (iteración visual — "la llama reacciona/se desestabiliza",
    // no solo crece). Ver flame.setSurgeDeform() en flame.js. Todo lo de
    // aquí se multiplica por la MISMA curva 0→1→0 de arriba (rise → hold
    // → fall, ver computeSurgeDeform() en candelaFinale.js) como
    // "intensity" — así el movimiento nace casi imperceptible (fase A,
    // "anticipación"), crece mientras la llama sube hacia el pico (fase
    // B, "inestabilidad"), es máximo en el pico (fase C, "surge") y se
    // apaga solo, de forma natural, durante la bajada (fase D,
    // "resolución") — sin necesitar una máquina de estados A/B/C/D
    // aparte.
    //
    // frequency* son en rad/s; amplitudes en radianes (tilt) o fracción
    // (pulse, p.ej. 0.12 = ±12% de anchura/altura extra). Dos frecuencias
    // combinadas (no una sola) para que el balanceo lateral no se sienta
    // metronómico — ver sección "IMPORTANTE: NO RANDOM POR FRAME" del
    // encargo: todo determinista, seno/coseno con fases fijas, nada de
    // Math.random() por frame.
    // -----------------------------------------------------------------------
    deform: {
      // Balanceo lateral (rotation.z): dos ondas de frecuencia distinta
      // sumadas — la base se mantiene anclada (pivote real de la llama,
      // ver comentario en flame.js), así que esto mueve sobre todo la
      // punta.
      lateralFrequency1: 2.4,
      lateralAmplitude1: 0.1,
      lateralFrequency2: 4.3,
      lateralAmplitude2: 0.045,
      lateralPhase2: 1.7,

      // Inclinación adicional hacia/desde cámara (rotation.x), más
      // suave que el balanceo lateral, para que no parezca un único eje
      // de movimiento repetitivo.
      tiltFrequency: 1.7,
      tiltAmplitude: 0.055,
      tiltPhase: 0.9,

      // Pulsación de anchura (scaleX/scaleZ) y altura (scaleY),
      // INDEPENDIENTES entre sí (frecuencias/fases distintas) para que
      // no crezcan/encojan siempre al mismo tiempo.
      widthFrequency: 5.1,
      widthAmplitude: 0.09,
      widthPhase: 2.4,
      heightFrequency: 3.6,
      heightAmplitude: 0.06,
      heightPhase: 0.3,
    },
  },

  // -----------------------------------------------------------------------
  // 3) PARTÍCULAS DEL SOBRE (ver secciones 3 y 5 del encargo). Mismo
  // lenguaje visual que FlameWords a propósito (mismo shader de brasa,
  // ver EMBER_VERTEX_SHADER/EMBER_FRAGMENT_SHADER reutilizados en
  // candelaFinale.js) pero un sistema totalmente independiente — no
  // comparte estado con flameWords.js ni lo modifica.
  // -----------------------------------------------------------------------
  particles: {
    // Cuántos frames de flameSurge (en segundos, desde que empieza a
    // crecer la llama) deben pasar antes de que nazca la primera
    // partícula. Pensado para caer cerca del pico (riseDuration=2.2 +
    // holdDuration=1.0=3.2 en total) pero un poco ANTES de que el pico
    // termine del todo, para que se lea como "la llama ya está
    // suficientemente intensa" y no como una casualidad de temporizador.
    startDelay: 2.6,

    // Capacidad reservada de una vez (buffer de tamaño fijo, sin crear
    // geometría nueva por frame — ver sección 13 del encargo). El
    // número real de partículas EN USO se recorta al nº de puntos que
    // consiga generar realmente el contorno del sobre (ver
    // envelope.sampling más abajo y selectEvenlyLocal en
    // candelaFinale.js) — así que esto es un TECHO, no una cantidad
    // fija garantizada.
    count: 340,

    // Paleta EXACTAMENTE igual a CONFIG.flame.colors/CONFIG.flameWords.colors
    // a propósito — mismo criterio que flameWords.config.js: estas
    // partículas deben ser, cromáticamente, indistinguibles de una brasa
    // real de la llama.
    colors: {
      core: 0xfffcf0,
      yellow: 0xffcf3d,
      orange: 0xff7215,
      edge: 0x7a1808,
    },

    size: {
      min: 0.012,
      max: 0.019,
    },

    // NACIMIENTO (ver sección 3 del encargo: "el origen debe basarse en
    // la referencia real de la llama"). Mismo criterio y misma fórmula
    // que cfg.flameOrigin en flameWords.config.js (radio que se ensancha
    // desde la base hasta el "bulge" y se estrecha hacia la punta,
    // calculado a partir de CONFIG.flame.shape) — se mantiene como una
    // copia independiente, no una importación cruzada, para que este
    // sistema no dependa de flameWords.js ni de su configuración (ver
    // sección 3 del encargo: "sin romper FlameWords").
    origin: {
      offset: [0, -0.026, 0.01],
      heightRange: [0.0, 0.3],
      bulgeT: 0.29,
      radiusAtBase: 0.03,
      radiusAtBulge: 0.075,
      radiusAtTop: 0.012,
      lateralBiasRange: [0.6, 1.9],
    },

    // FASES 1-2 de las propias partículas (BIRTH/RISE, igual criterio
    // que flameWords.js): comportamiento de brasa pura, sin ninguna
    // influencia todavía del contorno del sobre.
    birthDuration: 0.6,
    riseDuration: 1.1,
    birthScatter: 0.07,
    riseHeight: 0.2,
  },

  // -----------------------------------------------------------------------
  // 4) FORMA DEL SOBRE + 6) FORMACIÓN (ver secciones 4 y 6 del encargo).
  // La silueta se genera proceduralmente dibujando el CONTORNO (no el
  // relleno) del sobre en un canvas 2D oculto — igual concepto que
  // sampleWordPoints() en flameWords.js (nunca se muestra, solo se usa
  // para muestrear píxeles), pero una función propia e independiente
  // (ver sampleEnvelopeOutlinePoints() en candelaFinale.js): no se toca
  // flameWords.js para nada de esto.
  // -----------------------------------------------------------------------
  envelope: {
    // Tamaño del sobre en unidades de mundo. width/height es el cuerpo
    // rectangular; flapHeight es la altura adicional de la solapa
    // triangular por encima del cuerpo (la silueta completa mide
    // height + flapHeight).
    width: 0.27,
    height: 0.18,
    flapHeight: 0.095,

    // -----------------------------------------------------------------------
    // APARIENCIA DEL OBJETO FÍSICO (ver sección 8 del encargo: "color
    // papel cálido, iluminación coherente con la llama"). depth es el
    // grosor de la caja del cuerpo (muy fino, solo para que no sea un
    // plano sin volumen). roughness alto (mate, no brillante — un sobre
    // de papel, no plástico). No se define ninguna luz propia: el sobre
    // se ilumina con la PointLight de la llama y la luz ambiental que
    // ya existen en la escena (MeshStandardMaterial reacciona a ambas
    // sin configuración adicional).
    // -----------------------------------------------------------------------
    depth: 0.012,
    color: 0xe8d3a6,
    edgeColor: 0xc9a468,
    roughness: 0.85,

    // -----------------------------------------------------------------------
    // ITERACIÓN VISUAL — arreglo del "sobre gris" (ver diagnóstico
    // completo en envelopeMesh.js, justo donde se usan estos valores).
    // Resumen: lejos de la llama, la cara del sobre que mira a cámara
    // recibe muy poca luz directa de la PointLight de la llama (ángulo
    // rasante) y queda dominada por la luz ambiental/hemisférica de la
    // escena, que tiene un tono FRÍO/azulado (CONFIG.scene.hemisphere.
    // skyColor = 0x3a3f52) — al multiplicarse por ese tono, el papel
    // cálido (0xe8d3a6) se ve gris/apagado. Arreglo LOCAL, sin tocar
    // CONFIG.scene ni flame.js: una PointLight cálida pequeña, hija del
    // propio sobre (viaja con él, siempre ilumina su cara frontal desde
    // donde está la cámara) + un emissive sutil como suelo de color, no
    // como sustituto de la iluminación real (sigue reaccionando a
    // fillLight/flameLight/ambiente para conservar el volumen 3D).
    // -----------------------------------------------------------------------
    fillLight: {
      color: 0xffb066, // mismo tono que CONFIG.flame.light.color, a propósito
      intensity: 1.1,
      distance: 0.9,
      decay: 1.4,
      // Desplazamiento respecto al centro del sobre, en espacio LOCAL
      // del propio objeto (eje Z = hacia donde mira la cara frontal) —
      // así la luz sigue apuntando a la cara visible sea cual sea la
      // posición/orientación actual del sobre.
      offsetZ: 0.18,
    },
    // Suelo de color cálido (emissive) para que la cara frontal nunca
    // caiga a negro/gris puro en las zonas peor iluminadas — deliberadamente
    // bajo para no aplanar el sombreado 3D real (ver sección 1 del
    // encargo: "no quiero un material completamente emisivo").
    emissiveIntensity: 0.16,

    // Posición donde se LEE/forma el sobre, respecto a la mecha real de
    // la vela (igual criterio que cfg.anchor en flameWords.config.js —
    // onWickReady + este offset propio).
    anchorOffset: [0, 0.4, 0.05],

    // Resolución del muestreo del contorno. pixelsPerUnit define la
    // escala del canvas oculto (canvas = tamaño en unidades × este
    // valor), así el contorno mantiene SIEMPRE las proporciones reales
    // de width/height/flapHeight, sea cual sea su tamaño — no hay ningún
    // número de píxeles hardcodeado independiente del tamaño real.
    sampling: {
      pixelsPerUnit: 720,
      strokeWidthPx: 7,
      // Solo se consideran píxeles con alfa por encima de este umbral
      // (0-255) al muestrear el trazo — mismo criterio que
      // font.alphaThreshold en flameWords.config.js.
      alphaThreshold: 60,
    },
  },

  // FASE 3 de las partículas (CONVERGE): del comportamiento de brasa
  // pura al contorno del sobre — mismo criterio que
  // formation/reading en flameWords.config.js (arranque escalonado +
  // arco de curvatura, nunca una interpolación lineal directa).
  formation: {
    convergeDuration: 2.1,
    // Reparto del arranque entre partículas (0–1): con esto no todas
    // convergen a la vez, así se reconocen primero fragmentos sueltos
    // del contorno (esquinas, líneas de la solapa) y solo después el
    // sobre completo — ver sección 6 del encargo.
    stagger: 0.55,
    curlAmount: 0.05,
  },

  // -----------------------------------------------------------------------
  // 8) TRANSICIÓN PARTÍCULAS → SOBRE FÍSICO (ver sección 8 del encargo).
  // Una vez el contorno de partículas está formado y congelado, esta
  // fase hace aparecer el objeto físico (envelopeMesh.js) mientras las
  // partículas se desvanecen — ambas cosas a la vez, nunca un pop
  // instantáneo.
  // -----------------------------------------------------------------------
  materialize: {
    duration: 1.4,
  },

  // -----------------------------------------------------------------------
  // 7) EL SOBRE VIAJA AL CENTRO + 9) VIAJE Y ESTABILIZACIÓN (ver
  // secciones 7 y 9 del encargo). El destino se calcula en
  // candelaFinale.js a partir de la cámara REAL en ese momento
  // (camera.position + dirección de vista × distanceFromCamera +
  // desplazamiento vertical), nunca una coordenada fija — así funciona
  // sea cual sea el encuadre actual de CONFIG.camera.
  // -----------------------------------------------------------------------
  travel: {
    // Distancia delante de la cámara (unidades de mundo) a la que queda
    // el sobre una vez ha llegado.
    distanceFromCamera: 0.8,
    // Desplazamiento vertical (eje "up" de la propia cámara, no del
    // mundo) respecto al centro exacto del encuadre — ligeramente hacia
    // abajo para que no tape el techo del encuadre.
    verticalOffset: -0.04,
    // Punto de control de la curva (Bézier cuadrática spawn→destino):
    // cuánto se separa de la línea recta en altura ("arcHeight", eje
    // "up" de cámara) y lateralmente ("lateralOffset", eje "right" de
    // cámara) — ver sección 7 del encargo, "no quiero start → target
    // mecánico".
    arcHeight: 0.16,
    lateralOffset: 0.07,
    duration: 2.6,
  },

  // FASE de asentamiento tras llegar (ver sección 9: "no quiero que
  // llegue al centro y se abra inmediatamente").
  settle: {
    duration: 0.9,
  },

  // -----------------------------------------------------------------------
  // 10) APERTURA (ver sección 10 del encargo). flapAngle en radianes:
  // cuánto rota la solapa desde su borde (pivote real, ver
  // envelopeMesh.js — nunca desde su centro). pauseBefore/pauseAfter son
  // las dos pequeñas pausas pedidas explícitamente: una antes de que
  // empiece a levantarse, otra una vez ya está abierta antes de
  // continuar (a partir de ahí, "DETENTE" — ver sección 11 del
  // encargo).
  // -----------------------------------------------------------------------
  open: {
    flapAngle: Math.PI * 0.62,
    duration: 1.5,
    pauseBefore: 0.5,
    pauseAfter: 1.0,
  },

  // -----------------------------------------------------------------------
  // SEGUNDA PARTE DEL FINAL (ver encargo "SEGUNDA PARTE DEL FINAL
  // NARRATIVO"): continúa exactamente donde termina la primera parte
  // (sobre abierto, fase `open`/DONE de arriba) y no toca ninguno de los
  // bloques anteriores. Responsabilidad de src/letterMesh.js + la cola
  // de fases añadida en candelaFinale.js:
  //
  //   pause-after-open → letter-rise → final-hold → done
  //
  // El texto vive en `letter.pages` (más abajo), completamente
  // separado de cómo se anima/renderiza — cambiar el mensaje no
  // requiere tocar ninguna lógica.
  // -----------------------------------------------------------------------
  message: {
    // NOTA: ya no es la fuente de contenido de la carta (ver
    // `letter.pages` más abajo, que sustituyó a este campo cuando se
    // implementó el sistema de varias hojas) — se conserva sin usar
    // por si en el futuro hiciera falta un mensaje de referencia
    // fuera del sistema de páginas.
    text: "Te quiero",
  },

  letter: {
    // 1) PAUSA TRAS LA APERTURA (ver sección 1 del encargo de la
    // segunda parte): pequeña espera con el sobre ya abierto, antes de
    // que la carta empiece a salir — sensación de anticipación.
    pauseAfterOpen: 1.1,

    // Tamaño BASE de la carta ya completamente desplegada (ambas
    // mitades juntas), en unidades de mundo — proporcionado al tamaño
    // del sobre (cfg.envelope.width/height) para que se lea como "la
    // carta que estaba dentro de ESTE sobre", no un tamaño inventado
    // aparte. NO se ha tocado en esta iteración (ver `emerge.finalScale`
    // más abajo: el crecimiento durante la animación es un escalado
    // del `group` en tiempo real, nunca un cambio de esta geometría
    // base).
    width: 0.205,
    height: 0.29,

    // Apariencia física (mismo criterio que envelope: color papel
    // cálido, mate, sin textura externa; MeshStandardMaterial
    // reacciona a la PointLight de la llama y a la luz ambiental ya
    // existentes, sin luces propias). Un tono ligeramente más claro
    // que el sobre, como el papel interior real de una carta.
    color: 0xf7edd8,
    // NOTA: ya no se usa (vivía la línea decorativa del pliegue, ver
    // letterMesh.js — eliminada en esta iteración junto con todo el
    // sistema de doblado). Se conserva documentado por si una futura
    // iteración quisiera un acabado decorativo en el borde de la hoja.
    edgeColor: 0xd9c39c,
    roughness: 0.92,

    // -----------------------------------------------------------------------
    // ITERACIÓN — SE ABANDONA POR COMPLETO EL DOBLADO (ver encargo: "no
    // queremos que la hoja se doble, se despliegue ni se divida en dos
    // partes... quiero simplificarlo al máximo"). Ya no existen etapas
    // de pliegue/pausa/apertura: `emerge` gobierna una única transición
    // — la carta avanza desde el sobre hasta su posición final (ver
    // PHASE.LETTER_RISE en candelaFinale.js), ya completa, a su escala
    // definitiva y con el texto visible desde que aparece.
    // -----------------------------------------------------------------------
    emerge: {
      // Cuánto tarda la carta en llegar a su posición/opacidad final
      // (recorrido Bézier, ver computeLetterEmergePath() en
      // candelaFinale.js).
      duration: 1.9,

      // Punto de partida: igual criterio que iteraciones anteriores,
      // justo saliendo por la apertura del sobre ya asentado (ver
      // computeLetterEmergePath() en candelaFinale.js), cerca del
      // pivote real de la solapa (flapPivot en envelopeMesh.js, en
      // y = +height/2 = 0.09).
      startForwardOffset: 0.06,
      startHeight: 0.075,

      // Punto final: calculado respecto a la CÁMARA REAL (mismo
      // criterio que cfg.travel del sobre más arriba), NUNCA respecto
      // al sobre — así la carta termina SIEMPRE delante de él, sea
      // cual sea su posición exacta.
      //
      // ITERACIÓN — MÁS PRESENCIA EN PANTALLA (ver encargo: "quiero que
      // al finalizar la animación la hoja tenga una presencia
      // claramente mayor... una ampliación razonable, no exagerada").
      // `finalDistanceFromCamera` baja de 0.6 a 0.54 (10% más cerca de
      // la cámara). Sigue siendo deliberadamente MENOR que
      // `travel.distanceFromCamera` del sobre (0.8): más cerca de la
      // cámara que el sobre significa, por definición, delante de él
      // (ver "REGLA DE ORO" de un encargo anterior: "el sobre puede
      // quedar parcialmente tapado, eso es correcto"), y sigue con
      // margen de sobra respecto al near plane de la cámara (0.1, ver
      // config.js) — sin riesgo de clipping.
      finalDistanceFromCamera: 0.54,
      finalVerticalOffset: 0.02,

      // Curvatura sutil de la trayectoria (Bézier cuadrática, mismo
      // criterio que cfg.travel del sobre) — nunca una línea recta
      // "robótica".
      arcHeight: 0.05,
      lateralOffset: 0.02,

      // Escala FINAL del `group` de la carta (nunca de la geometría
      // base, ver width/height más arriba), fijada DESDE EL PRIMER
      // FRAME de LETTER_RISE (ver candelaFinale.js) — nunca una rampa:
      // "debe aparecer ya con su geometría final/tamaño final" (ver
      // encargo de una iteración anterior).
      //
      // ITERACIÓN — sube de 1.2 a 1.3 (junto con el acercamiento de
      // `finalDistanceFromCamera` de arriba) para una presencia
      // claramente mayor en pantalla, sin resultar exagerada: a 60cm
      // de la cámara real (fov=56°, ver config.js) la carta pasa de
      // ocupar ≈54% a ≈66% de la altura del encuadre y de ≈22% a ≈26%
      // del ancho — sigue leyéndose como una hoja delante del sobre,
      // nunca tapando la escena. 1.3 → un 30% más grande que el
      // tamaño base (0.205×0.29 → 0.267×0.377). Sigue del mismo orden
      // de magnitud que el sobre (cuerpo 0.27×0.18 + solapa 0.095 de
      // alto ≈ 0.27×0.275 de silueta total).
      finalScale: 1.3,
    },

    // -----------------------------------------------------------------------
    // ITERACIÓN — OBJETIVO 2: SISTEMA REAL DE PASAR HOJAS (ver encargo).
    //
    // `pages` es la ÚNICA fuente de verdad del CONTENIDO de la carta:
    // un array de { title?, text }, en el orden en que se leen. Añadir,
    // quitar, reordenar o editar hojas es cambiar SOLO este array — ni
    // candelaFinale.js ni letterMesh.js hardcodean ningún número de
    // hojas ni su contenido (ver letterMesh.js: `pages.map(...)`
    // construye tantas hojas físicas como entradas tenga este array).
    //
    // `title` es opcional (una hoja sin `title` simplemente no dibuja
    // ninguno, ver buildPageTexture() en letterMesh.js).
    //
    // Se mantiene un único ejemplo por defecto con el mismo mensaje que
    // ya existía ("Te quiero", antes en `message.text` de arriba) para
    // no cambiar el comportamiento visible si nadie añade más hojas.
    // -----------------------------------------------------------------------
    pages: [
      {
        title: undefined,
        text: "Te quiero",
      },
    ],

    // -----------------------------------------------------------------------
    // PASE DE PÁGINA (ver "ANIMACIÓN HACIA DELANTE"/"HACIA ATRÁS" del
    // encargo): cada hoja es un plano independiente con su propio
    // pivote vertical en el borde IZQUIERDO de la carta (mismo
    // lenguaje que `flapPivot`/`hingePivot` ya usado en este proyecto:
    // se rota el PIVOTE, nunca la geometría). `nextPage()` gira la
    // hoja actual de 0 a -180° (pasa hacia el final del conjunto);
    // `previousPage()` gira la hoja anterior de -180° a 0° (vuelve
    // hacia delante) — ver letterMesh.js.
    // -----------------------------------------------------------------------
    page: {
      // Duración de la animación de pasar página (segundos), igual en
      // ambos sentidos (ver "Quiero que el movimiento sea coherente en
      // ambas direcciones" del encargo).
      turnDuration: 0.9,
      // Separación mínima en el eje Z entre hojas apiladas, solo para
      // evitar z-fighting entre planos casi coplanares — nunca para
      // cambiar el tamaño/posición general de la carta (ver
      // letterMesh.js: es un desplazamiento imperceptible por hoja).
      stackSpacing: 0.00006,

      // TÍTULO (ver "TEXTO DE CADA HOJA" del encargo: centrado, arriba,
      // con margen, nunca pegado al borde). Comparte canvas con el
      // cuerpo del texto (ver buildPageTexture() en letterMesh.js) —
      // mismo criterio que el resto del proyecto: un único canvas
      // oculto, nunca HTML/DOM.
      //
      // ITERACIÓN — REDISEÑO (ver encargo: "el título debe tener un
      // tamaño MAYOR que el texto normal" — antes 40px de título contra
      // 46px de cuerpo, exactamente al revés). `sizePx` sube a 52
      // (ahora claramente mayor que `text.font.sizePx` = 34, más
      // abajo). Se añade `separator`: una línea fina decorativa bajo
      // el título (ver mockup del encargo), horneada en la misma
      // textura — nunca un elemento aparte.
      title: {
        // Margen superior antes del título, y separación entre el
        // título (o el separador, si existe) y el texto que viene
        // debajo — ambos como fracción de la altura del canvas oculto
        // (mismo criterio de resolución relativa que
        // `text.font.canvasHeightPx` más abajo, así el margen se
        // mantiene proporcional sea cual sea el tamaño real de la
        // carta).
        marginTopFraction: 0.1,
        gapFraction: 0.06,
        font: {
          family: "Georgia, 'Times New Roman', serif",
          weight: "bold",
          sizePx: 52,
          color: "#3d2a17",
        },
        // Línea fina decorativa bajo el título, centrada — marca con
        // claridad la frontera entre título y cuerpo (ver mockup del
        // encargo). `widthFraction` es su longitud como fracción del
        // ancho del canvas; `color` reutiliza el mismo tono cálido que
        // ya usa el borde del sobre (cfg.envelope.edgeColor) para
        // mantener una paleta coherente en toda la escena.
        separator: {
          enabled: true,
          widthFraction: 0.22,
          thicknessPx: 2,
          color: "#c9a468",
          gapAboveFraction: 0.022,
        },
      },
    },

    // 4)-6) TEXTO DE CADA HOJA (ver secciones 4, 5 y 6 del encargo
    // original + "TEXTO DE CADA HOJA" de encargos anteriores). El
    // texto se genera como una textura de canvas 2D (mismo criterio
    // que createSoftGlowTexture()/sampleWordPoints() en este proyecto:
    // canvas oculto, nunca visible como tal, solo usado para generar
    // una textura), horneada directamente sobre la propia hoja — nunca
    // HTML/DOM (ver buildPageTexture() en letterMesh.js). Esta
    // configuración de fuente/ajuste de línea se aplica a TODAS las
    // hojas por igual (el contenido, no el estilo, es lo que cambia
    // entre hojas — ver `pages` arriba).
    //
    // ITERACIÓN — LA HOJA QUE SALE YA TIENE EL TEXTO (ver encargo de
    // una iteración anterior: "no quiero hoja vacía → espera →
    // segunda capa con el texto"). `delay`/`revealDuration` ya NO
    // gobiernan ningún fundido propio y retrasado (se conservan
    // documentados, no usados). `riseDistance` SÍ se sigue usando: la
    // ligera subida de la página está sincronizada con la misma
    // opacidad que el resto de la carta, nunca con un progreso propio.
    //
    // ITERACIÓN — REDISEÑO DE LA COMPOSICIÓN (ver encargo: "el texto se
    // ve demasiado grande y empieza prácticamente desde el centro de
    // la hoja"). `sizePx` baja de 46 a 34 (más pequeño que el título,
    // ver arriba) y `lineHeightPx` baja en la misma proporción (de 60
    // a 44). `maxWidthFraction` baja de 0.78 a 0.74 para unos márgenes
    // laterales algo más marcados. Se añade `topMarginFraction`: el
    // margen superior que usa el cuerpo cuando la página NO tiene
    // título (antes, sin título, el texto se centraba en toda la
    // altura del canvas — ver buildPageTexture() en letterMesh.js,
    // ahora siempre se ancla arriba, nunca centrado verticalmente).
    text: {
      // NOTA: ya NO gobiernan un fundido propio y retrasado de la
      // página (ver nota de iteración arriba) — no usados actualmente.
      delay: 0.55,
      revealDuration: 1.9,
      // Cuánto "sube" el texto mientras aparece (unidades de mundo,
      // muy sutil) — sincronizado con la MISMA opacidad que el libro
      // (ver setAppearance() en letterMesh.js), nunca con un progreso
      // propio.
      riseDistance: 0.018,
      // Margen superior del cuerpo (fracción de la altura del canvas)
      // cuando la página NO tiene título — ver buildPageTexture() en
      // letterMesh.js.
      topMarginFraction: 0.12,
      font: {
        // Georgia: misma familia que ya usa flameWords.config.js para
        // coherencia tipográfica en todo el proyecto.
        family: "Georgia, 'Times New Roman', serif",
        weight: "normal",
        sizePx: 34,
        lineHeightPx: 44,
        color: "#3d2a17",
        // Resolución del canvas oculto usado para generar la textura
        // (alto en píxeles; el ancho se calcula a partir de esto y de
        // letter.width/letter.height para que el texto nunca salga
        // deformado, sea cual sea el tamaño real de la carta).
        canvasHeightPx: 640,
        // Fracción del ancho del canvas disponible para el ajuste de
        // línea automático (word-wrap) antes de saltar de línea —
        // también actúa como margen lateral visual (a menor fracción,
        // mayor margen a los lados).
        maxWidthFraction: 0.74,
        // NOTA: ya no gobierna un plano de texto aparte (antes existía
        // `textMesh`, un plano independiente más pequeño que el papel).
        // Desde esta iteración el texto se hornea directamente sobre
        // la propia hoja (ver `pages`/`page` arriba y buildPageTexture()
        // en letterMesh.js), a tamaño completo de la carta — se
        // conserva este valor sin usar por si una futura iteración
        // vuelve a necesitar un margen de plano independiente.
        marginFraction: 0.86,
      },
    },
  },

  // FASE FINAL ESTABLE (ver sección 7 del encargo: "la escena no debe
  // continuar haciendo animaciones innecesarias" + "puede haber...
  // respiración visual muy ligera"). `finalHold` es la pausa tras
  // completarse la aparición del mensaje antes de considerar la
  // secuencia terminada del todo (DONE); `idle` gobierna la
  // respiración vertical, sutil y continua, de la carta una vez
  // terminado — nunca de la cámara, la iluminación ni el sobre.
  finalHold: {
    duration: 1.2,
  },
  idle: {
    amplitude: 0.0035,
    frequency: 0.45,
  },
};
